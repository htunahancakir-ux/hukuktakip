@echo off
cd /d "%~dp0"
node outputs\icrapro\server.cjs
pause
